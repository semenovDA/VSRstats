import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from peakutils import peak
from struct import unpack
import math
import os


class nonlinear:
    
    def __init__(self):
        pass
        
